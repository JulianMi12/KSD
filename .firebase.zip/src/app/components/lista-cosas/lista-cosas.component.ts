import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-cosas',
  templateUrl: './lista-cosas.component.html',
  styleUrls: ['./lista-cosas.component.css']
})
export class ListaCosasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
